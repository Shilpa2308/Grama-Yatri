package com.gramayatri.app.model

data class Village(
    val id: String = "",
    val name: String = "",
    val orderIndex: Int = 0,
    val avgMinutesToNext: Int = 10
)

data class Route(
    val id: String = "",
    val name: String = "",
    val villages: List<Village> = emptyList()
)

data class Ping(
    val id: String = "",
    val routeId: String = "",
    val villageId: String = "",
    val villageName: String = "",
    val type: String = "ON_BUS", // ON_BUS or PASSED_STOP
    val reporterName: String = "Anonymous",
    val timestamp: Long = 0L,
    val lat: Double? = null,
    val lng: Double? = null
)

data class Alert(
    val id: String = "",
    val routeId: String = "",
    val message: String = "",
    val reporterName: String = "Anonymous",
    val timestamp: Long = 0L
)

data class StopEta(
    val village: Village,
    val etaMinutes: Int?,   // null if unknown
    val isPassed: Boolean,
    val isCurrent: Boolean
)
