package com.gramayatri.app.ui

import androidx.compose.animation.*
import androidx.compose.runtime.*
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.gramayatri.app.ui.screens.LiveTrackingScreen
import com.gramayatri.app.ui.screens.RouteSelectScreen
import com.gramayatri.app.ui.screens.VillageSelectScreen
import com.gramayatri.app.viewmodel.BusViewModel

@Composable
fun GramaYatriApp() {
    val nav = rememberNavController()
    val vm: BusViewModel = viewModel()

    // IMPROVEMENT: Slide animations between screens
    NavHost(
        navController = nav,
        startDestination = "routes",
        enterTransition = { slideInHorizontally { it } + fadeIn() },
        exitTransition = { slideOutHorizontally { -it } + fadeOut() },
        popEnterTransition = { slideInHorizontally { -it } + fadeIn() },
        popExitTransition = { slideOutHorizontally { it } + fadeOut() }
    ) {
        composable("routes") {
            RouteSelectScreen(vm = vm, onRouteSelected = { nav.navigate("villages") })
        }
        composable("villages") {
            VillageSelectScreen(
                vm = vm,
                onBack = { nav.popBackStack() },
                onVillageSelected = { nav.navigate("live") }
            )
        }
        composable("live") {
            LiveTrackingScreen(vm = vm, onBack = { nav.popBackStack() })
        }
    }
}
