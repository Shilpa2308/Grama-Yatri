package com.gramayatri.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gramayatri.app.viewmodel.BusViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VillageSelectScreen(vm: BusViewModel, onBack: () -> Unit, onVillageSelected: () -> Unit) {
    val routes by vm.routes.collectAsState()
    val rid    by vm.selectedRouteId.collectAsState()
    val route  = routes.firstOrNull { it.id == rid }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(route?.name ?: "Select Village",
                            fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text("Where are you boarding?", fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.85f))
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor    = Color(0xFF1B5E20),
                    titleContentColor = Color.White
                )
            )
        },
        containerColor = Color(0xFFF1F8E9)
    ) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).fillMaxSize()) {
            Text("Select your village stop",
                fontWeight = FontWeight.Bold, fontSize = 15.sp,
                color = Color(0xFF1B5E20))
            Text("The app will calculate ETA for your village",
                fontSize = 12.sp, color = Color(0xFF757575))
            Spacer(Modifier.height(12.dp))

            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(route?.villages ?: emptyList(), key = { it.id }) { v ->
                    Card(
                        modifier  = Modifier.fillMaxWidth().clickable {
                            vm.selectVillage(v.id); onVillageSelected()
                        },
                        colors    = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(2.dp)
                    ) {
                        Row(Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.LocationOn,
                                contentDescription = null,
                                tint     = Color(0xFF2E7D32),
                                modifier = Modifier.size(28.dp))
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text(v.name, fontWeight = FontWeight.SemiBold,
                                    fontSize = 15.sp)
                                if (v.avgMinutesToNext > 0)
                                    Text("About ${v.avgMinutesToNext} min to next stop",
                                        fontSize = 12.sp, color = Color(0xFF757575))
                                else
                                    Text("Last stop on route",
                                        fontSize = 12.sp, color = Color(0xFF757575))
                            }
                        }
                    }
                }
            }
        }
    }
}
