package com.gramayatri.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

// IMPROVEMENT: Richer colour palette
private val LightColors = lightColorScheme(
    primary          = Color(0xFF1B8A3A),
    onPrimary        = Color.White,
    primaryContainer = Color(0xFFD6F5E0),
    onPrimaryContainer = Color(0xFF00391A),
    secondary        = Color(0xFFFF8F00),
    onSecondary      = Color.White,
    secondaryContainer = Color(0xFFFFECCC),
    background       = Color(0xFFF7F8F4),
    surface          = Color.White,
    surfaceVariant   = Color(0xFFEEF4EE),
    error            = Color(0xFFB00020),
    errorContainer   = Color(0xFFFFDAD6)
)

private val DarkColors = darkColorScheme(
    primary          = Color(0xFF74D88B),
    onPrimary        = Color(0xFF00391A),
    primaryContainer = Color(0xFF00531F),
    secondary        = Color(0xFFFFB74D),
    background       = Color(0xFF1A1C1A),
    surface          = Color(0xFF2C2F2C),
    surfaceVariant   = Color(0xFF3A3D3A),
    errorContainer   = Color(0xFF8C1D18)
)

@Composable
fun GramaYatriTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        content = content
    )
}
