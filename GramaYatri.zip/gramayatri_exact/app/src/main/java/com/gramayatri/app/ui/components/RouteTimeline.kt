package com.gramayatri.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gramayatri.app.model.StopEta

@Composable
fun RouteTimeline(stops: List<StopEta>, selectedVillageId: String? = null) {
    Column(Modifier.fillMaxWidth()) {
        stops.forEachIndexed { index, s ->
            val isMyStop  = s.village.id == selectedVillageId
            val dotColor  = when {
                s.isCurrent -> Color(0xFFFF6F00)   // orange - bus is here
                s.isPassed  -> Color(0xFF4CAF50)    // green  - already passed
                else        -> Color(0xFFBDBDBD)    // grey   - upcoming
            }

            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {

                // Timeline column
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.width(40.dp)
                ) {
                    // Dot
                    Box(
                        Modifier
                            .size(if (s.isCurrent) 24.dp else 16.dp)
                            .clip(CircleShape)
                            .background(dotColor),
                        contentAlignment = Alignment.Center
                    ) {
                        if (s.isCurrent)
                            Text("B", fontSize = 10.sp,
                                color = Color.White, fontWeight = FontWeight.Bold)
                    }
                    // Line connecting to next stop
                    if (index != stops.lastIndex) {
                        Canvas(Modifier.width(3.dp).height(56.dp)) {
                            drawLine(
                                color       = if (s.isPassed || s.isCurrent)
                                                  Color(0xFF4CAF50) else Color(0xFFE0E0E0),
                                start       = Offset(size.width / 2, 0f),
                                end         = Offset(size.width / 2, size.height),
                                strokeWidth = 4f
                            )
                        }
                    }
                }

                Spacer(Modifier.width(10.dp))

                // Stop info
                Box(
                    Modifier
                        .weight(1f)
                        .padding(bottom = 4.dp)
                        .then(
                            if (isMyStop) Modifier.background(
                                Color(0xFFE8F5E9),
                                shape = MaterialTheme.shapes.small
                            ).padding(horizontal = 8.dp, vertical = 4.dp)
                            else Modifier.padding(bottom = 8.dp)
                        )
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                s.village.name,
                                fontWeight = if (s.isCurrent || isMyStop)
                                                 FontWeight.Bold else FontWeight.Normal,
                                fontSize   = 14.sp,
                                color      = if (s.isPassed) Color(0xFF757575)
                                             else Color(0xFF212121)
                            )
                            if (isMyStop) {
                                Spacer(Modifier.width(6.dp))
                                Text("You",
                                    fontSize   = 11.sp,
                                    color      = Color(0xFF2E7D32),
                                    fontWeight = FontWeight.Bold)
                            }
                        }
                        // ETA text — matching spec "Bus will reach your village in ~15 mins"
                        val etaText = when {
                            s.isCurrent          -> "Bus is here now"
                            s.isPassed           -> "Bus has passed"
                            s.etaMinutes == null -> "Waiting for ping data"
                            s.etaMinutes == 0    -> "Bus arriving now"
                            else -> "Bus will reach in ~${s.etaMinutes} mins"
                        }
                        Text(
                            etaText,
                            fontSize = 12.sp,
                            color    = when {
                                s.isCurrent           -> Color(0xFFFF6F00)
                                s.isPassed            -> Color(0xFF9E9E9E)
                                s.etaMinutes != null  -> Color(0xFF1565C0)
                                else                  -> Color(0xFF9E9E9E)
                            },
                            fontWeight = if (isMyStop && s.etaMinutes != null)
                                             FontWeight.SemiBold else FontWeight.Normal
                        )
                    }
                }
            }
        }
    }
}
