package com.gramayatri.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gramayatri.app.viewmodel.BusViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RouteSelectScreen(vm: BusViewModel, onRouteSelected: () -> Unit) {
    val routes    by vm.routes.collectAsState()
    val name      by vm.reporterName.collectAsState()
    val isLoading by vm.isLoading.collectAsState()

    val nameIsValid = name.isNotBlank() && name != "Anonymous"
    var nameTouched by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Grama-Yatri", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        Text("Community Bus Tracker", fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onPrimary.copy(alpha = 0.85f))
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor    = Color(0xFF1B5E20),
                    titleContentColor = Color.White
                )
            )
        },
        containerColor = Color(0xFFF1F8E9)
    ) { pad ->
        Column(Modifier.padding(pad).padding(16.dp).fillMaxSize()) {

            // Name card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors   = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("Your Name", fontWeight = FontWeight.SemiBold,
                        color = Color(0xFF1B5E20), fontSize = 13.sp)
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value         = if (name == "Anonymous") "" else name,
                        onValueChange = { nameTouched = true; vm.setReporterName(it) },
                        label         = { Text("Enter your name *") },
                        placeholder   = { Text("e.g. Ravi, Kavya, Shilpa") },
                        singleLine    = true,
                        isError       = nameTouched && !nameIsValid,
                        supportingText = {
                            if (nameTouched && !nameIsValid)
                                Text("Name is required", color = MaterialTheme.colorScheme.error)
                            else
                                Text("Your name will appear on every ping — e.g. Reported by Ravi")
                        },
                        leadingIcon = { Icon(Icons.Default.Person, contentDescription = null,
                            tint = Color(0xFF2E7D32)) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            Spacer(Modifier.height(16.dp))

            Text("Select Your Route", fontWeight = FontWeight.Bold,
                fontSize = 15.sp, color = Color(0xFF1B5E20))
            Spacer(Modifier.height(8.dp))

            when {
                isLoading -> {
                    Box(Modifier.fillMaxWidth().padding(40.dp),
                        contentAlignment = Alignment.Center) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            CircularProgressIndicator(color = Color(0xFF2E7D32))
                            Spacer(Modifier.height(12.dp))
                            Text("Loading routes...", fontSize = 13.sp,
                                color = Color(0xFF555555))
                        }
                    }
                }

                routes.isEmpty() -> {
                    Card(Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(2.dp)) {
                        Column(Modifier.padding(20.dp)) {
                            Text("No routes found", fontWeight = FontWeight.SemiBold)
                            Spacer(Modifier.height(4.dp))
                            Text("Tap below to load demo data",
                                fontSize = 12.sp, color = Color(0xFF757575))
                            Spacer(Modifier.height(12.dp))
                            Button(
                                onClick  = { nameTouched = true; if (nameIsValid) vm.seedDemoData() },
                                enabled  = nameIsValid,
                                modifier = Modifier.fillMaxWidth(),
                                colors   = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF2E7D32))
                            ) {
                                Icon(Icons.Default.DirectionsBus, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text("Load Demo Route")
                            }
                            if (nameTouched && !nameIsValid) {
                                Spacer(Modifier.height(6.dp))
                                Text("Please enter your name first",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.error)
                            }
                        }
                    }
                }

                else -> {
                    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(routes, key = { it.id }) { r ->
                            Card(
                                modifier  = Modifier.fillMaxWidth().clickable {
                                    nameTouched = true
                                    if (nameIsValid) { vm.selectRoute(r.id); onRouteSelected() }
                                },
                                colors    = CardDefaults.cardColors(
                                    containerColor = if (nameIsValid) Color.White
                                    else Color(0xFFF5F5F5)),
                                elevation = CardDefaults.cardElevation(2.dp)
                            ) {
                                Row(Modifier.padding(16.dp),
                                    verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        Modifier.size(48.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.DirectionsBus,
                                            contentDescription = null,
                                            tint = if (nameIsValid) Color(0xFF2E7D32)
                                                   else Color(0xFFBDBDBD),
                                            modifier = Modifier.size(36.dp))
                                    }
                                    Spacer(Modifier.width(12.dp))
                                    Column {
                                        Text(r.name, fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp,
                                            color = if (nameIsValid) Color(0xFF212121)
                                                    else Color(0xFFBDBDBD))
                                        Text("${r.villages.size} stops on this route",
                                            fontSize = 12.sp, color = Color(0xFF757575))
                                        if (!nameIsValid && nameTouched) {
                                            Text("Enter your name to select",
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.error)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
