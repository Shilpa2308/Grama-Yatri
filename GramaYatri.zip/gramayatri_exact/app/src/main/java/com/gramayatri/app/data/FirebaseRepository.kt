package com.gramayatri.app.data

import com.google.firebase.database.*
import com.gramayatri.app.model.*
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

class FirebaseRepository {

    private val db: FirebaseDatabase by lazy {
        FirebaseDatabase.getInstance(
            "https://gramayatri-607a1-default-rtdb.firebaseio.com"
        ).apply {
            try { setPersistenceEnabled(true) } catch (_: Exception) {}
        }
    }

    private val routesRef: DatabaseReference get() = db.getReference("routes")
    private val pingsRef:  DatabaseReference get() = db.getReference("pings")
    private val alertsRef: DatabaseReference get() = db.getReference("alerts")

    // ── OBSERVE ALL ROUTES ─────────────────────────────────────────────
    fun observeRoutes(): Flow<List<Route>> = callbackFlow {
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val routes = mutableListOf<Route>()

                for (routeSnap in snapshot.children) {
                    val id = routeSnap.key ?: continue
                    val name = routeSnap.child("name")
                        .getValue(String::class.java) ?: id

                    val villages = mutableListOf<Village>()
                    for (v in routeSnap.child("villages").children) {
                        val vid = v.key ?: continue
                        val vName = v.child("name")
                            .getValue(String::class.java) ?: vid
                        val order = (v.child("orderIndex")
                            .getValue(Long::class.java) ?: 0L).toInt()
                        val avg = (v.child("avgMinutesToNext")
                            .getValue(Long::class.java) ?: 0L).toInt()

                        villages.add(
                            Village(
                                id = vid,
                                name = vName,
                                orderIndex = order,
                                avgMinutesToNext = avg
                            )
                        )
                    }

                    routes.add(
                        Route(
                            id = id,
                            name = name,
                            villages = villages.sortedBy { it.orderIndex }
                        )
                    )
                }

                trySend(routes.sortedBy { it.id })
            }

            override fun onCancelled(error: DatabaseError) {
                close(error.toException())
            }
        }

        routesRef.keepSynced(true)
        routesRef.addValueEventListener(listener)

        awaitClose { routesRef.removeEventListener(listener) }
    }

    // ── OBSERVE PINGS (FINAL FIXED) ────────────────────────────────────
    fun observePings(routeId: String): Flow<List<Ping>> = callbackFlow {

        val ref = pingsRef.child(routeId).limitToLast(50)

        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {

                val pings = mutableListOf<Ping>()

                for (p in snapshot.children) {
                    val id = p.key ?: continue

                    pings.add(
                        Ping(
                            id = id,
                            routeId = p.child("routeId")
                                .getValue(String::class.java) ?: routeId,
                            villageId = p.child("villageId")
                                .getValue(String::class.java) ?: "",
                            villageName = p.child("villageName")
                                .getValue(String::class.java) ?: "",
                            type = p.child("type")
                                .getValue(String::class.java) ?: "ON_BUS",
                            reporterName = p.child("reporterName")
                                .getValue(String::class.java) ?: "Anonymous",
                            timestamp = p.child("timestamp")
                                .getValue(Long::class.java) ?: 0L,
                            lat = p.child("lat")
                                .getValue(Double::class.java),
                            lng = p.child("lng")
                                .getValue(Double::class.java)
                        )
                    )
                }

                // ✅ FIX: remove duplicates + keep latest first
                val sorted = pings
                    .distinctBy { it.id }
                    .sortedByDescending { it.timestamp }

                trySend(sorted)
            }

            override fun onCancelled(error: DatabaseError) {
                close(error.toException())
            }
        }

        pingsRef.child(routeId).keepSynced(true)
        ref.addValueEventListener(listener)

        awaitClose {
            ref.removeEventListener(listener)
        }
    }

    // ── OBSERVE ALERTS ─────────────────────────────────────────────────
    fun observeAlerts(routeId: String): Flow<List<Alert>> = callbackFlow {

        val ref = alertsRef.child(routeId).limitToLast(10)

        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {

                val alerts = mutableListOf<Alert>()

                for (a in snapshot.children) {
                    val id = a.key ?: continue

                    alerts.add(
                        Alert(
                            id = id,
                            routeId = routeId,
                            message = a.child("message")
                                .getValue(String::class.java) ?: "",
                            reporterName = a.child("reporterName")
                                .getValue(String::class.java) ?: "Anonymous",
                            timestamp = a.child("timestamp")
                                .getValue(Long::class.java) ?: 0L
                        )
                    )
                }

                val sorted = alerts.sortedByDescending { it.timestamp }

                trySend(sorted)
            }

            override fun onCancelled(error: DatabaseError) {
                close(error.toException())
            }
        }

        alertsRef.child(routeId).keepSynced(true)
        ref.addValueEventListener(listener)

        awaitClose {
            ref.removeEventListener(listener)
        }
    }

    // ── SEND PING ──────────────────────────────────────────────────────
    fun sendPing(ping: Ping) {
        val ref = pingsRef.child(ping.routeId).push()
        val id = ref.key ?: return

        val map = hashMapOf<String, Any?>(
            "id" to id,
            "routeId" to ping.routeId,
            "villageId" to ping.villageId,
            "villageName" to ping.villageName,
            "type" to ping.type,
            "reporterName" to ping.reporterName,
            "timestamp" to ping.timestamp,
            "lat" to ping.lat,
            "lng" to ping.lng
        )

        ref.setValue(map)
    }

    // ── SEND ALERT ─────────────────────────────────────────────────────
    fun sendAlert(alert: Alert) {
        val ref = alertsRef.child(alert.routeId).push()
        val id = ref.key ?: return

        val map = hashMapOf<String, Any?>(
            "id" to id,
            "routeId" to alert.routeId,
            "message" to alert.message,
            "reporterName" to alert.reporterName,
            "timestamp" to alert.timestamp
        )

        ref.setValue(map)
    }

    // ── DELETE OLD PINGS ───────────────────────────────────────────────
    fun deleteOldPings(routeId: String, cutoffTimestamp: Long) {
        pingsRef.child(routeId)
            .orderByChild("timestamp")
            .endAt(cutoffTimestamp.toDouble())
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    snapshot.children.forEach { it.ref.removeValue() }
                }
                override fun onCancelled(error: DatabaseError) {}
            })
    }

    // ── SEED SAMPLE DATA ───────────────────────────────────────────────
    fun seedSampleData() {
        val sampleRoutes = listOf(
            Triple("route1", "Anandapur → Eshwarapura", listOf(
                Village("v1", "Anandapur", 0, 8),
                Village("v2", "Belur", 1, 12),
                Village("v3", "Chikmagalur", 2, 10),
                Village("v4", "Devarahalli", 3, 15),
                Village("v5", "Eshwarapura", 4, 0)
            ))
        )

        for ((routeId, routeName, villages) in sampleRoutes) {
            routesRef.child(routeId).child("name").setValue(routeName)

            for (v in villages) {
                val vMap = hashMapOf<String, Any>(
                    "name" to v.name,
                    "orderIndex" to v.orderIndex,
                    "avgMinutesToNext" to v.avgMinutesToNext
                )

                routesRef.child(routeId)
                    .child("villages")
                    .child(v.id)
                    .setValue(vMap)
            }
        }
    }
}