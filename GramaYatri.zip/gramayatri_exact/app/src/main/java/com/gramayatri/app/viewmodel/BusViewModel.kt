package com.gramayatri.app.viewmodel

import android.annotation.SuppressLint
import android.app.Application
import android.location.Location
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.android.gms.location.*
import com.gramayatri.app.data.FirebaseRepository
import com.gramayatri.app.model.Alert
import com.gramayatri.app.model.Ping
import com.gramayatri.app.model.Route
import com.gramayatri.app.model.StopEta
import com.gramayatri.app.util.EtaCalculator
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class BusViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = FirebaseRepository()
    private val fusedLocation: FusedLocationProviderClient =
        LocationServices.getFusedLocationProviderClient(application)

    private val _routes = MutableStateFlow<List<Route>>(emptyList())
    val routes: StateFlow<List<Route>> = _routes.asStateFlow()

    private val _selectedRouteId = MutableStateFlow<String?>(null)
    val selectedRouteId: StateFlow<String?> = _selectedRouteId.asStateFlow()

    private val _selectedVillageId = MutableStateFlow<String?>(null)
    val selectedVillageId: StateFlow<String?> = _selectedVillageId.asStateFlow()

    private val _pings = MutableStateFlow<List<Ping>>(emptyList())
    val pings: StateFlow<List<Ping>> = _pings.asStateFlow()

    private val _alerts = MutableStateFlow<List<Alert>>(emptyList())
    val alerts: StateFlow<List<Alert>> = _alerts.asStateFlow()

    private val _stops = MutableStateFlow<List<StopEta>>(emptyList())
    val stops: StateFlow<List<StopEta>> = _stops.asStateFlow()

    private val _reporterName = MutableStateFlow("Anonymous")
    val reporterName: StateFlow<String> = _reporterName.asStateFlow()

    private val _isLoading = MutableStateFlow(true)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _pingSuccess = MutableStateFlow<String?>(null)
    val pingSuccess: StateFlow<String?> = _pingSuccess.asStateFlow()

    private val _currentLocation = MutableStateFlow<Location?>(null)
    val currentLocation: StateFlow<Location?> = _currentLocation.asStateFlow()

    private val _locationStatus = MutableStateFlow("Location not fetched")
    val locationStatus: StateFlow<String> = _locationStatus.asStateFlow()

    private val clockTick = flow {
        while (true) { emit(System.currentTimeMillis()); delay(30_000L) }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, System.currentTimeMillis())

    init {
        loadRoutes()
        observePings()
        observeAlerts()
        computeEtas()
    }

    private fun loadRoutes() {
        viewModelScope.launch {
            repo.observeRoutes().collect {
                _routes.value = it
                _isLoading.value = false
            }
        }
    }

    private fun observePings() {
        viewModelScope.launch {
            _selectedRouteId.flatMapLatest { id ->
                if (id == null) flowOf(emptyList()) else repo.observePings(id)
            }.collect { fromFirebase ->
                val current = _pings.value.toMutableList()

                // Step 1: For each Firebase ping, check if it matches a local "local_" ping
                // by villageId + timestamp within 30 seconds. If so, replace the local one
                // with the confirmed Firebase one (which has the real server ID).
                // This prevents duplicates when Firebase returns the same ping with a new ID.
                for (fbPing in fromFirebase) {
                    val localIndex = current.indexOfFirst { local ->
                        local.id.startsWith("local_") &&
                                local.villageId == fbPing.villageId &&
                                kotlin.math.abs(local.timestamp - fbPing.timestamp) < 30_000L
                    }
                    if (localIndex != -1) {
                        // Replace local copy with confirmed Firebase copy
                        current[localIndex] = fbPing
                    } else if (current.none { it.id == fbPing.id }) {
                        // Genuinely new ping from another user — add it
                        current.add(fbPing)
                    }
                    // If id already exists in current → already tracked, skip
                }

                _pings.value = current.sortedByDescending { it.timestamp }
            }
        }
    }

    private fun observeAlerts() {
        viewModelScope.launch {
            _selectedRouteId.flatMapLatest { id ->
                if (id == null) flowOf(emptyList()) else repo.observeAlerts(id)
            }.collect { fromFirebase ->
                val current = _alerts.value.toMutableList()

                // Same logic as observePings: match local alert to Firebase alert
                // by message + timestamp within 30 seconds, then replace local with Firebase copy.
                for (fbAlert in fromFirebase) {
                    val localIndex = current.indexOfFirst { local ->
                        local.id.startsWith("local_") &&
                                local.message == fbAlert.message &&
                                kotlin.math.abs(local.timestamp - fbAlert.timestamp) < 30_000L
                    }
                    if (localIndex != -1) {
                        // Replace local copy with confirmed Firebase copy
                        current[localIndex] = fbAlert
                    } else if (current.none { it.id == fbAlert.id }) {
                        // Genuinely new alert from another user — add it
                        current.add(fbAlert)
                    }
                }

                _alerts.value = current.sortedByDescending { it.timestamp }
            }
        }
    }

    private fun computeEtas() {
        viewModelScope.launch {
            combine(_routes, _selectedRouteId, _pings, clockTick) { routes, rid, pings, now ->
                val route = routes.firstOrNull { it.id == rid } ?: return@combine emptyList<StopEta>()
                EtaCalculator.compute(route, pings, now)
            }.collect { _stops.value = it }
        }
    }

    fun setReporterName(name: String) { if (name.isNotBlank()) _reporterName.value = name.trim() }

    fun selectRoute(id: String) {
        if (_selectedRouteId.value == id) return
        _selectedRouteId.value   = id
        _selectedVillageId.value = null
        // NEVER clear _pings or _alerts
    }

    fun selectVillage(id: String) { _selectedVillageId.value = id }

    fun pingOnBus()      = sendPing("ON_BUS")
    fun pingPassedStop() = sendPing("PASSED_STOP")

    private fun sendPing(type: String) {
        val rid = _selectedRouteId.value ?: run { showSnackbar("❌ No route selected"); return }
        val vid = _selectedVillageId.value ?: run { showSnackbar("❌ No stop selected"); return }
        val village = _routes.value.firstOrNull { it.id == rid }
            ?.villages?.firstOrNull { it.id == vid }
            ?: run { showSnackbar("❌ Stop not found"); return }

        val ts  = System.currentTimeMillis()
        val loc = _currentLocation.value

        val ping = Ping(
            id           = "local_$ts",
            routeId      = rid,
            villageId    = vid,
            villageName  = village.name,
            type         = type,
            reporterName = _reporterName.value,
            timestamp    = ts,
            lat          = loc?.latitude,
            lng          = loc?.longitude
        )

        // Add locally FIRST — UI shows it instantly
        // observePings() will later swap "local_$ts" → real Firebase ID without duplicating
        val updated = _pings.value.toMutableList()
        updated.add(0, ping)
        _pings.value = updated

        // Write to Firebase async
        repo.sendPing(ping)

        // Recompute ETA immediately
        _routes.value.firstOrNull { it.id == rid }?.let { route ->
            _stops.value = EtaCalculator.compute(route, _pings.value, ts)
        }

        val label = if (type == "ON_BUS") "I am on the bus" else "Bus passed my stop"
        showSnackbar("✅ Ping sent: $label at ${village.name}")
    }

    fun postAlert(message: String) {
        val rid = _selectedRouteId.value ?: run { showSnackbar("❌ No route"); return }
        if (message.isBlank()) return

        val ts = System.currentTimeMillis()
        val alert = Alert(
            id           = "local_$ts",
            routeId      = rid,
            message      = message.trim(),
            reporterName = _reporterName.value,
            timestamp    = ts
        )

        // Add locally FIRST — UI shows it instantly
        // observeAlerts() will later swap "local_$ts" → real Firebase ID without duplicating
        val updated = _alerts.value.toMutableList()
        updated.add(0, alert)
        _alerts.value = updated

        // Write to Firebase async
        repo.sendAlert(alert)

        showSnackbar("✅ Alert posted!")
    }

    // Controls snackbar ONLY — never touches _pings or _alerts
    private fun showSnackbar(msg: String) {
        _pingSuccess.value = msg
        viewModelScope.launch {
            delay(3000)
            _pingSuccess.value = null
        }
    }

    @SuppressLint("MissingPermission")
    fun fetchLocation() {
        _locationStatus.value = "Fetching..."
        fusedLocation.lastLocation.addOnSuccessListener { loc ->
            if (loc != null) {
                _currentLocation.value = loc
                _locationStatus.value = "${String.format("%.4f", loc.latitude)}, ${String.format("%.4f", loc.longitude)}"
            } else {
                val req = CurrentLocationRequest.Builder().setPriority(Priority.PRIORITY_HIGH_ACCURACY).build()
                fusedLocation.getCurrentLocation(req, null).addOnSuccessListener { fresh ->
                    _currentLocation.value = fresh
                    _locationStatus.value = if (fresh != null)
                        "${String.format("%.4f", fresh.latitude)}, ${String.format("%.4f", fresh.longitude)}"
                    else "Could not get location"
                }
            }
        }.addOnFailureListener { _locationStatus.value = "Error" }
    }

    fun seedDemoData() = repo.seedSampleData()

    fun clearOldPings() {
        val rid = _selectedRouteId.value ?: return
        viewModelScope.launch {
            repo.deleteOldPings(rid, System.currentTimeMillis() - 4 * 60 * 60 * 1000L)
        }
    }
}