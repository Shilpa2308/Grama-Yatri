package com.gramayatri.app.ui

import androidx.compose.animation.*
import androidx.compose.runtime.*
import androidx.lifecycle.viewmodel.compose.viewModel
import com.gramayatri.app.ui.screens.MainTrackingScreen
import com.gramayatri.app.ui.screens.RouteSelectScreen
import com.gramayatri.app.ui.screens.VillageSelectScreen
import com.gramayatri.app.ui.screens.WelcomeScreen
import com.gramayatri.app.viewmodel.BusViewModel

enum class Screen {
    WELCOME, ROUTE_SELECT, VILLAGE_SELECT, MAIN_TRACKING
}

@Composable
fun GramaYatriApp() {
    val vm: BusViewModel = viewModel()
    var current by remember { mutableStateOf(Screen.WELCOME) }

    AnimatedContent(
        targetState = current,
        transitionSpec = {
            slideInHorizontally { it } + fadeIn() togetherWith
                    slideOutHorizontally { -it } + fadeOut()
        },
        label = "nav"
    ) { screen ->
        when (screen) {
            Screen.WELCOME -> {
                WelcomeScreen(
                    vm         = vm,
                    onContinue = { current = Screen.ROUTE_SELECT }
                )
            }
            Screen.ROUTE_SELECT -> {
                RouteSelectScreen(
                    vm              = vm,
                    onRouteSelected = { current = Screen.VILLAGE_SELECT }
                )
            }
            Screen.VILLAGE_SELECT -> {
                VillageSelectScreen(
                    vm               = vm,
                    onBack           = { current = Screen.ROUTE_SELECT },
                    onVillageSelected = { current = Screen.MAIN_TRACKING }
                )
            }
            Screen.MAIN_TRACKING -> {
                MainTrackingScreen(vm = vm)
            }
        }
    }
}