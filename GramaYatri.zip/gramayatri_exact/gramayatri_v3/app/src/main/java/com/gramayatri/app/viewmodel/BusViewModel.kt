package com.gramayatri.app.viewmodel

import android.annotation.SuppressLint
import android.app.Application
import android.location.Location
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.android.gms.location.*
import com.gramayatri.app.data.FirebaseRepository
import com.gramayatri.app.model.Alert
import com.gramayatri.app.model.Ping
import com.gramayatri.app.model.Route
import com.gramayatri.app.model.StopEta
import com.gramayatri.app.util.EtaCalculator
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

@OptIn(ExperimentalCoroutinesApi::class)
class BusViewModel(application: Application) : AndroidViewModel(application) {

    private val repo = FirebaseRepository()

    // Location client
    private val fusedLocation: FusedLocationProviderClient =
        LocationServices.getFusedLocationProviderClient(application)

    private val _routes          = MutableStateFlow<List<Route>>(emptyList())
    val routes: StateFlow<List<Route>> = _routes.asStateFlow()

    private val _selectedRouteId = MutableStateFlow<String?>(null)
    val selectedRouteId: StateFlow<String?> = _selectedRouteId.asStateFlow()

    private val _selectedVillageId = MutableStateFlow<String?>(null)
    val selectedVillageId: StateFlow<String?> = _selectedVillageId.asStateFlow()

    private val _pings  = MutableStateFlow<List<Ping>>(emptyList())
    val pings: StateFlow<List<Ping>> = _pings.asStateFlow()

    private val _alerts = MutableStateFlow<List<Alert>>(emptyList())
    val alerts: StateFlow<List<Alert>> = _alerts.asStateFlow()

    private val _stops  = MutableStateFlow<List<StopEta>>(emptyList())
    val stops: StateFlow<List<StopEta>> = _stops.asStateFlow()

    private val _reporterName = MutableStateFlow("Anonymous")
    val reporterName: StateFlow<String> = _reporterName.asStateFlow()

    private val _isLoading = MutableStateFlow(true)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _pingSuccess = MutableStateFlow<String?>(null)
    val pingSuccess: StateFlow<String?> = _pingSuccess.asStateFlow()

    // Location state — shown in UI
    private val _currentLocation = MutableStateFlow<Location?>(null)
    val currentLocation: StateFlow<Location?> = _currentLocation.asStateFlow()

    private val _locationStatus = MutableStateFlow("Location: not fetched")
    val locationStatus: StateFlow<String> = _locationStatus.asStateFlow()

    // ETA clock tick every 30 sec
    private val clockTick = flow {
        while (true) { emit(System.currentTimeMillis()); delay(30_000L) }
    }.stateIn(viewModelScope, SharingStarted.Eagerly, System.currentTimeMillis())

    init {
        viewModelScope.launch {
            repo.observeRoutes().collectLatest {
                _routes.value = it
                _isLoading.value = false
            }
        }
        viewModelScope.launch {
            _selectedRouteId.flatMapLatest { id ->
                if (id == null) flowOf(emptyList()) else repo.observePings(id)
            }.collectLatest { _pings.value = it }
        }
        viewModelScope.launch {
            _selectedRouteId.flatMapLatest { id ->
                if (id == null) flowOf(emptyList()) else repo.observeAlerts(id)
            }.collectLatest { _alerts.value = it }
        }
        viewModelScope.launch {
            combine(_routes, _selectedRouteId, _pings, clockTick) { routes, rid, pings, now ->
                val r = routes.firstOrNull { it.id == rid } ?: return@combine emptyList()
                EtaCalculator.compute(r, pings, now)
            }.collectLatest { _stops.value = it }
        }
    }

    fun setReporterName(name: String) {
        _reporterName.value = name.ifBlank { "Anonymous" }
    }

    fun selectRoute(id: String) {
        _selectedRouteId.value   = id
        _selectedVillageId.value = null
        _pings.value  = emptyList()
        _alerts.value = emptyList()
    }

    fun selectVillage(id: String) { _selectedVillageId.value = id }

    // Called from UI after permission is granted
    @SuppressLint("MissingPermission")
    fun fetchLocation() {
        _locationStatus.value = "📍 Fetching location…"
        fusedLocation.lastLocation.addOnSuccessListener { loc ->
            if (loc != null) {
                _currentLocation.value = loc
                _locationStatus.value  =
                    "📍 ${String.format("%.4f", loc.latitude)}, ${String.format("%.4f", loc.longitude)}"
            } else {
                // lastLocation can be null on fresh device — request a fresh one
                val req = CurrentLocationRequest.Builder()
                    .setPriority(Priority.PRIORITY_HIGH_ACCURACY)
                    .build()
                fusedLocation.getCurrentLocation(req, null)
                    .addOnSuccessListener { freshLoc ->
                        _currentLocation.value = freshLoc
                        _locationStatus.value  = if (freshLoc != null)
                            "📍 ${String.format("%.4f", freshLoc.latitude)}, ${String.format("%.4f", freshLoc.longitude)}"
                        else
                            "⚠ Could not get location"
                    }
            }
        }.addOnFailureListener {
            _locationStatus.value = "⚠ Location error: ${it.message}"
        }
    }

    fun pingOnBus()     = sendPing("ON_BUS")
    fun pingPassedStop() = sendPing("PASSED_STOP")

    private fun sendPing(type: String) {
        val rid     = _selectedRouteId.value   ?: return
        val vid     = _selectedVillageId.value ?: return
        val village = _routes.value.firstOrNull { it.id == rid }
                          ?.villages?.firstOrNull { it.id == vid } ?: return
        val loc     = _currentLocation.value
        repo.sendPing(
            Ping(
                routeId      = rid,
                villageId    = vid,
                villageName  = village.name,
                type         = type,
                reporterName = _reporterName.value,
                timestamp    = System.currentTimeMillis(),
                lat          = loc?.latitude,
                lng          = loc?.longitude
            )
        )
        val label = if (type == "ON_BUS") "I am on the bus" else "Bus passed my stop"
        _pingSuccess.value = "✅ Ping sent: $label at ${village.name}"
        viewModelScope.launch { delay(3000); _pingSuccess.value = null }
    }

    fun postAlert(message: String) {
        val rid = _selectedRouteId.value ?: return
        if (message.isBlank()) return
        repo.sendAlert(
            Alert(
                routeId      = rid,
                message      = message.trim(),
                reporterName = _reporterName.value,
                timestamp    = System.currentTimeMillis()
            )
        )
    }

    fun seedDemoData() = repo.seedSampleData()

    fun clearOldPings() {
        val rid    = _selectedRouteId.value ?: return
        val cutoff = System.currentTimeMillis() - 4 * 60 * 60 * 1000L
        viewModelScope.launch { repo.deleteOldPings(rid, cutoff) }
    }
}
