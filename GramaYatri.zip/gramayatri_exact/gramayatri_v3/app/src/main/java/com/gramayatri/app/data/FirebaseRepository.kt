package com.gramayatri.app.data

import com.google.firebase.database.*
import com.gramayatri.app.model.*
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

class FirebaseRepository {

    private val db: FirebaseDatabase by lazy {
        FirebaseDatabase.getInstance("https://grama-yatri-609f2-default-rtdb.firebaseio.com").apply {
            // IMPROVEMENT: Offline persistence for rural low-network areas
            try { setPersistenceEnabled(true) } catch (_: Exception) {}
        }
    }

    private val routesRef: DatabaseReference get() = db.getReference("routes")
    private val pingsRef: DatabaseReference get() = db.getReference("pings")
    private val alertsRef: DatabaseReference get() = db.getReference("alerts")

    fun observeRoutes(): Flow<List<Route>> = callbackFlow {
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val routes = snapshot.children.mapNotNull { routeSnap ->
                    val id = routeSnap.key ?: return@mapNotNull null
                    val name = routeSnap.child("name").getValue(String::class.java) ?: id
                    val villages = routeSnap.child("villages").children.mapNotNull { v ->
                        val vid = v.key ?: return@mapNotNull null
                        Village(
                            id = vid,
                            name = v.child("name").getValue(String::class.java) ?: vid,
                            orderIndex = (v.child("orderIndex").getValue(Long::class.java) ?: 0L).toInt(),
                            avgMinutesToNext = (v.child("avgMinutesToNext").getValue(Long::class.java) ?: 10L).toInt()
                        )
                    }.sortedBy { it.orderIndex }
                    Route(id = id, name = name, villages = villages)
                }
                trySend(routes)
            }
            override fun onCancelled(error: DatabaseError) { close(error.toException()) }
        }
        routesRef.keepSynced(true)
        routesRef.addValueEventListener(listener)
        awaitClose { routesRef.removeEventListener(listener) }
    }

    // IMPROVEMENT: Only fetch last 50 pings using limitToLast — avoids loading entire history
    fun observePings(routeId: String): Flow<List<Ping>> = callbackFlow {
        val ref = pingsRef.child(routeId).limitToLast(50)
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val pings = snapshot.children.mapNotNull { p ->
                    val id = p.key ?: return@mapNotNull null
                    Ping(
                        id = id,
                        routeId = p.child("routeId").getValue(String::class.java) ?: routeId,
                        villageId = p.child("villageId").getValue(String::class.java) ?: "",
                        villageName = p.child("villageName").getValue(String::class.java) ?: "",
                        type = p.child("type").getValue(String::class.java) ?: "ON_BUS",
                        reporterName = p.child("reporterName").getValue(String::class.java) ?: "Anonymous",
                        timestamp = p.child("timestamp").getValue(Long::class.java) ?: 0L,
                        lat = p.child("lat").getValue(Double::class.java),
                        lng = p.child("lng").getValue(Double::class.java)
                    )
                }.sortedByDescending { it.timestamp }
                trySend(pings)
            }
            override fun onCancelled(error: DatabaseError) { close(error.toException()) }
        }
        pingsRef.child(routeId).keepSynced(true)
        ref.addValueEventListener(listener)
        awaitClose { ref.removeEventListener(listener) }
    }

    // IMPROVEMENT: Only fetch last 10 alerts
    fun observeAlerts(routeId: String): Flow<List<Alert>> = callbackFlow {
        val ref = alertsRef.child(routeId).limitToLast(10)
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val alerts = snapshot.children.mapNotNull { a ->
                    val id = a.key ?: return@mapNotNull null
                    Alert(
                        id = id,
                        routeId = routeId,
                        message = a.child("message").getValue(String::class.java) ?: "",
                        reporterName = a.child("reporterName").getValue(String::class.java) ?: "Anonymous",
                        timestamp = a.child("timestamp").getValue(Long::class.java) ?: 0L
                    )
                }.sortedByDescending { it.timestamp }
                trySend(alerts)
            }
            override fun onCancelled(error: DatabaseError) { close(error.toException()) }
        }
        alertsRef.child(routeId).keepSynced(true)
        ref.addValueEventListener(listener)
        awaitClose { ref.removeEventListener(listener) }
    }

    fun sendPing(ping: Ping) {
        val ref = pingsRef.child(ping.routeId).push()
        val id = ref.key ?: return
        ref.setValue(ping.copy(id = id))
    }

    fun sendAlert(alert: Alert) {
        val ref = alertsRef.child(alert.routeId).push()
        val id = ref.key ?: return
        ref.setValue(alert.copy(id = id))
    }

    // IMPROVEMENT: Delete pings older than cutoff to keep DB lean
    fun deleteOldPings(routeId: String, cutoffTimestamp: Long) {
        pingsRef.child(routeId)
            .orderByChild("timestamp")
            .endAt(cutoffTimestamp.toDouble())
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    snapshot.children.forEach { it.ref.removeValue() }
                }
                override fun onCancelled(error: DatabaseError) {}
            })
    }

    fun seedSampleData() {
        val villages = listOf(
            Village("v1", "Anandapur", 0, 8),
            Village("v2", "Belur", 1, 12),
            Village("v3", "Chikmagalur", 2, 10),
            Village("v4", "Devarahalli", 3, 15),
            Village("v5", "Eshwarapura", 4, 0)
        )
        val route = Route("route1", "Anandapur → Eshwarapura", villages)
        routesRef.child(route.id).child("name").setValue(route.name)
        villages.forEach { v ->
            val vMap = mapOf(
                "name" to v.name,
                "orderIndex" to v.orderIndex,
                "avgMinutesToNext" to v.avgMinutesToNext
            )
            routesRef.child(route.id).child("villages").child(v.id).setValue(vMap)
        }
    }
}
