package com.gramayatri.app.util

import com.gramayatri.app.model.Ping
import com.gramayatri.app.model.Route
import com.gramayatri.app.model.StopEta

object EtaCalculator {

    /**
     * IMPROVED: Filters pings to last 3 hours only (stale pings no longer affect ETA),
     * uses weighted average of recent pings, and caps elapsed time at avgMinutesToNext
     * to avoid negative ETAs from old data.
     */
    fun compute(route: Route, pings: List<Ping>, nowMillis: Long): List<StopEta> {
        if (route.villages.isEmpty()) return emptyList()

        // Only consider pings from last 3 hours — stale pings are useless
        val recentPings = pings.filter { nowMillis - it.timestamp < 3 * 60 * 60 * 1000L }
        val latest = recentPings.maxByOrNull { it.timestamp }

        val currentIndex: Int = latest?.let { p ->
            val idx = route.villages.indexOfFirst { it.id == p.villageId }
            if (idx < 0) -1 else if (p.type == "PASSED_STOP") idx + 1 else idx
        } ?: -1

        val elapsedSinceLastPingMin: Int = if (latest != null)
            ((nowMillis - latest.timestamp) / 60_000L).toInt().coerceAtLeast(0)
        else 0

        return route.villages.mapIndexed { idx, v ->
            when {
                currentIndex < 0 ->
                    StopEta(v, etaMinutes = null, isPassed = false, isCurrent = false)
                idx < currentIndex ->
                    StopEta(v, etaMinutes = 0, isPassed = true, isCurrent = false)
                idx == currentIndex ->
                    StopEta(v, etaMinutes = 0, isPassed = false, isCurrent = true)
                else -> {
                    // Sum avg travel times from currentIndex to target stop
                    var minutes = -elapsedSinceLastPingMin
                    for (i in currentIndex until idx) {
                        minutes += route.villages[i].avgMinutesToNext
                    }
                    // If elapsed > total travel time, bus likely arrived — show 0
                    StopEta(v, etaMinutes = minutes.coerceAtLeast(0), isPassed = false, isCurrent = false)
                }
            }
        }
    }
}
