package com.gramayatri.app.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.gramayatri.app.model.StopEta
import com.gramayatri.app.viewmodel.BusViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainTrackingScreen(
    vm: BusViewModel,
    onOpenLiveTracking: () -> Unit = {}
) {
    val context     = LocalContext.current
    val routes      by vm.routes.collectAsState()
    val rid         by vm.selectedRouteId.collectAsState()
    val vid         by vm.selectedVillageId.collectAsState()
    val stops       by vm.stops.collectAsState()
    val pings       by vm.pings.collectAsState()
    val alerts      by vm.alerts.collectAsState()
    val pingSuccess by vm.pingSuccess.collectAsState()
    val name        by vm.reporterName.collectAsState()
    val isLoading   by vm.isLoading.collectAsState()

    val route     = routes.firstOrNull { it.id == rid }
    val myStop    = stops.firstOrNull { it.village.id == vid }
    val myVillage = route?.villages?.firstOrNull { it.id == vid }

    val timeFmt           = remember { SimpleDateFormat("hh:mm a", Locale.getDefault()) }
    val snackbarHostState = remember { SnackbarHostState() }
    var showAlertDialog   by remember { mutableStateOf(false) }
    var alertText         by remember { mutableStateOf("") }
    var showNameDialog    by remember { mutableStateOf(false) }
    var editNameText      by remember { mutableStateOf("") }

    val locationLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        if (perms[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            perms[Manifest.permission.ACCESS_COARSE_LOCATION] == true)
            vm.fetchLocation()
    }

    LaunchedEffect(Unit) {
        val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION)
        if (fine == PackageManager.PERMISSION_GRANTED) vm.fetchLocation()
        else locationLauncher.launch(arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION))
    }

    // KEY FIX: early-return on null so the snackbar is never cancelled
    // when pingSuccess resets to null after 3 seconds
    LaunchedEffect(pingSuccess) {
        val msg = pingSuccess ?: return@LaunchedEffect
        snackbarHostState.showSnackbar(msg, duration = SnackbarDuration.Short)
    }

    Scaffold(
        snackbarHost   = { SnackbarHost(snackbarHostState) },
        containerColor = Color(0xFFF5F0E8)
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState())) {

            // ── TOP HEADER ─────────────────────────────────────────────
            Row(
                Modifier.fillMaxWidth().background(Color.White)
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(38.dp).clip(CircleShape).background(Color(0xFF2E7D32)),
                    contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.DirectionsBus, null,
                        tint = Color.White, modifier = Modifier.size(22.dp))
                }
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f)) {
                    Text("Grama-Yatri", fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1)
                    Text("ROUTE: ${route?.name?.uppercase() ?: "SELECT A ROUTE"}",
                        fontSize = 9.sp, color = Color(0xFF757575),
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(14.dp).clip(CircleShape).background(Color(0xFF2E7D32)),
                            contentAlignment = Alignment.Center) {
                            Text(name.firstOrNull()?.uppercaseChar()?.toString() ?: "?",
                                fontSize = 7.sp, color = Color.White, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.width(3.dp))
                        Text(name, fontSize = 9.sp, color = Color(0xFF2E7D32),
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
                OutlinedButton(
                    onClick = { showAlertDialog = true },
                    shape  = RoundedCornerShape(6.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFE65100)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFE65100)),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    modifier = Modifier.height(32.dp)
                ) { Text("Report", fontSize = 10.sp, fontWeight = FontWeight.SemiBold) }
                Spacer(Modifier.width(6.dp))
                Button(
                    onClick = { vm.pingOnBus() },
                    shape  = RoundedCornerShape(6.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                    modifier = Modifier.height(32.dp)
                ) { Text("On Bus", fontSize = 10.sp, fontWeight = FontWeight.SemiBold) }
            }

            // ── PINGING AS BANNER ──────────────────────────────────────
            Row(
                Modifier.fillMaxWidth().background(Color(0xFFE8F5E9))
                    .padding(horizontal = 16.dp, vertical = 5.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Pinging as: $name  •  Stop: ${myVillage?.name ?: "-"}",
                    fontSize = 10.sp, color = Color(0xFF1B5E20), fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                TextButton(
                    onClick = { editNameText = name; showNameDialog = true },
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 0.dp)
                ) { Text("Change", fontSize = 10.sp, color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold) }
            }

            Spacer(Modifier.height(10.dp))

            Row(
                Modifier.fillMaxWidth().padding(horizontal = 10.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalAlignment = Alignment.Top
            ) {
                // ── LEFT PANEL ─────────────────────────────────────────
                Column(Modifier.width(160.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {

                    // Active Tracking Card
                    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(2.dp)) {
                        Column(Modifier.padding(10.dp)) {
                            Text("ACTIVE TRACKING", fontSize = 8.sp,
                                color = Color(0xFF757575), letterSpacing = 1.sp)
                            Spacer(Modifier.height(4.dp))
                            if (isLoading) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp),
                                    color = Color(0xFF2E7D32), strokeWidth = 2.dp)
                            } else {
                                val etaText = when {
                                    myStop == null            -> "Waiting for ping"
                                    myStop.isCurrent          -> "Bus is here!"
                                    myStop.isPassed           -> "Bus passed"
                                    myStop.etaMinutes == null -> "Waiting..."
                                    myStop.etaMinutes == 0    -> "Arriving now!"
                                    else -> "~${myStop.etaMinutes} Mins Away"
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("🚌", fontSize = 16.sp)
                                    Spacer(Modifier.width(4.dp))
                                    Text(etaText, fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp, color = Color(0xFF1B5E20),
                                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                Text("Stop: ${myVillage?.name ?: "-"}",
                                    fontSize = 10.sp, color = Color(0xFF757575),
                                    maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }

                            // ── ALERT BOX — always rendered when alerts exist ──
                            // alerts list is never wiped, so this stays permanently
                            if (alerts.isNotEmpty()) {
                                Spacer(Modifier.height(6.dp))
                                Box(
                                    Modifier.fillMaxWidth()
                                        .background(Color(0xFFFFF8E1), RoundedCornerShape(6.dp))
                                        .padding(6.dp)
                                ) {
                                    Column {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text("⚠", fontSize = 10.sp, color = Color(0xFFE65100))
                                            Spacer(Modifier.width(3.dp))
                                            Text("ROUTE ALERT", fontSize = 8.sp,
                                                color = Color(0xFFE65100),
                                                fontWeight = FontWeight.Bold)
                                        }
                                        Spacer(Modifier.height(2.dp))
                                        Text(
                                            "\"${alerts.first().message}\"",
                                            fontSize = 9.sp, color = Color(0xFF424242),
                                            lineHeight = 13.sp, maxLines = 3,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            "By ${alerts.first().reporterName}",
                                            fontSize = 8.sp, color = Color(0xFF9E9E9E),
                                            maxLines = 1, overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // ── RECENT PINGS CARD ──────────────────────────────
                    // Always shown — placeholder text when no pings yet
                    // pings list is never wiped so entries stay permanently
                    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(2.dp)) {
                        Column(Modifier.padding(10.dp)) {
                            Text("RECENT PINGS", fontSize = 8.sp,
                                color = Color(0xFF757575), letterSpacing = 1.sp)
                            Spacer(Modifier.height(6.dp))

                            if (pings.isEmpty()) {
                                // Placeholder — always visible, never disappears
                                Text(
                                    "No pings yet.\nTap \"On Bus\" to\nbe the first!",
                                    fontSize = 9.sp, color = Color(0xFF9E9E9E),
                                    lineHeight = 13.sp
                                )
                            } else {
                                pings.take(5).forEachIndexed { index, p ->
                                    Row(
                                        Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Box(
                                            Modifier.size(28.dp).clip(CircleShape)
                                                .background(Color(0xFFE8F5E9)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                p.reporterName.firstOrNull()
                                                    ?.uppercaseChar()?.toString() ?: "?",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFF2E7D32)
                                            )
                                        }
                                        Spacer(Modifier.width(6.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(
                                                p.reporterName,
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                if (p.type == "ON_BUS")
                                                    "Boarded at ${p.villageName}"
                                                else "Passed ${p.villageName}",
                                                fontSize = 9.sp,
                                                color = Color(0xFF757575),
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                        val minsAgo = ((System.currentTimeMillis() - p.timestamp)
                                                / 60000L).toInt().coerceAtLeast(0)
                                        Text(
                                            if (minsAgo < 1) "now" else "${minsAgo}m",
                                            fontSize = 9.sp,
                                            color = Color(0xFF9E9E9E)
                                        )
                                    }
                                    if (index < pings.take(5).size - 1) {
                                        HorizontalDivider(
                                            color = Color(0xFFF5F5F5),
                                            modifier = Modifier.padding(vertical = 1.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // No routes helper card
                    if (routes.isEmpty() && !isLoading) {
                        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White)) {
                            Column(Modifier.padding(10.dp)) {
                                Text("No routes found",
                                    fontWeight = FontWeight.SemiBold, fontSize = 11.sp)
                                Spacer(Modifier.height(6.dp))
                                Button(
                                    onClick = { vm.seedDemoData() },
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = Color(0xFF2E7D32)),
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("Load Demo", fontSize = 11.sp) }
                            }
                        }
                    }
                }

                // ── RIGHT PANEL — tap to open full Live Tracking screen ─
                Card(
                    Modifier.weight(1f).clickable { onOpenLiveTracking() },
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(2.dp)
                ) {
                    Column(Modifier.padding(12.dp)) {
                        Row(Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically) {
                            Text("Live Route Map",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                maxLines = 1,
                                modifier = Modifier.weight(1f))
                            val remaining = stops.count { !it.isPassed && !it.isCurrent }
                            if (remaining > 0) {
                                Box(
                                    Modifier.background(Color(0xFFE8F5E9), RoundedCornerShape(10.dp))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text("$remaining left", fontSize = 9.sp,
                                        color = Color(0xFF2E7D32),
                                        fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        if (stops.isEmpty()) {
                            Box(Modifier.fillMaxWidth().padding(16.dp),
                                contentAlignment = Alignment.Center) {
                                Text("Loading route...",
                                    color = Color(0xFF9E9E9E), fontSize = 11.sp)
                            }
                        } else {
                            stops.forEachIndexed { index, stop ->
                                StopRowItem(
                                    stop    = stop,
                                    isMyStop = stop.village.id == vid,
                                    isLast   = index == stops.lastIndex,
                                    timeFmt  = timeFmt
                                )
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        HorizontalDivider(color = Color(0xFFEEEEEE))
                        Spacer(Modifier.height(6.dp))
                        Text(
                            "Tap to open full route →",
                            fontSize = 8.sp,
                            color = Color(0xFF2E7D32),
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.fillMaxWidth(),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            // ── BOTTOM BIG PING BUTTON ─────────────────────────────────
            Spacer(Modifier.height(14.dp))
            Button(
                onClick = { vm.pingOnBus() },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 4.dp)
                    .height(65.dp),
                shape  = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1B5E20)),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 4.dp)
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("I SEE THE BUS", color = Color.White,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 17.sp, letterSpacing = 1.sp)
                    Text("PING YOUR LOCATION",
                        color = Color.White.copy(alpha = 0.75f),
                        fontSize = 9.sp, letterSpacing = 1.5.sp)
                }
            }
            Spacer(Modifier.height(6.dp))
            Text(
                "© 2025 • GRAMA-YATRI COMMUNITY • LOW DATA MODE ENABLED",
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 4.dp),
                fontSize = 7.sp,
                color = Color(0xFF9E9E9E),
                textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(8.dp))
        }
    }

    // ── CHANGE NAME DIALOG ─────────────────────────────────────────────────
    if (showNameDialog) {
        AlertDialog(
            onDismissRequest = { showNameDialog = false },
            title = { Text("Change Your Name", fontWeight = FontWeight.Bold) },
            text  = {
                Column {
                    Text("Your name appears on every ping.",
                        fontSize = 12.sp, color = Color(0xFF757575))
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value         = editNameText,
                        onValueChange = { editNameText = it },
                        label         = { Text("Your name") },
                        singleLine    = true,
                        modifier      = Modifier.fillMaxWidth(),
                        colors        = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF2E7D32),
                            focusedLabelColor  = Color(0xFF2E7D32)
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (editNameText.isNotBlank()) {
                            vm.setReporterName(editNameText.trim())
                            showNameDialog = false
                        }
                    },
                    enabled = editNameText.isNotBlank(),
                    colors  = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
                ) { Text("Save") }
            },
            dismissButton = {
                TextButton(onClick = { showNameDialog = false }) { Text("Cancel") }
            }
        )
    }

    // ── REPORT ALERT DIALOG ────────────────────────────────────────────────
    if (showAlertDialog) {
        AlertDialog(
            onDismissRequest = { showAlertDialog = false },
            icon  = { Icon(Icons.Default.Warning, null, tint = Color(0xFFE65100)) },
            title = { Text("Report Community Alert") },
            text  = {
                Column {
                    listOf(
                        "Morning bus is cancelled today",
                        "Bus running 30 minutes late",
                        "Evening 6:00 PM bus delayed",
                        "Bus is full, next one coming"
                    ).forEach { s ->
                        OutlinedButton(
                            onClick  = { alertText = s },
                            modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                        ) { Text(s, fontSize = 12.sp) }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value         = alertText,
                        onValueChange = { alertText = it },
                        label         = { Text("Custom message") },
                        modifier      = Modifier.fillMaxWidth(),
                        minLines      = 2
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        vm.postAlert(alertText)
                        alertText = ""
                        showAlertDialog = false
                    },
                    enabled = alertText.isNotBlank(),
                    colors  = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
                ) { Text("Post Alert") }
            },
            dismissButton = {
                TextButton(onClick = { showAlertDialog = false }) { Text("Cancel") }
            }
        )
    }
}

// ── STOP ROW ITEM ──────────────────────────────────────────────────────────
@Composable
fun StopRowItem(stop: StopEta, isMyStop: Boolean, isLast: Boolean, timeFmt: SimpleDateFormat) {
    val isCurrent = stop.isCurrent
    val isPassed  = stop.isPassed
    val bgColor   = when {
        isCurrent -> Color(0xFFF1F8E9)
        isMyStop  -> Color(0xFFF9FBE7)
        else      -> Color.Transparent
    }
    val dotColor  = when {
        isCurrent -> Color(0xFF2E7D32)
        isPassed  -> Color(0xFFBDBDBD)
        else      -> Color(0xFFE0E0E0)
    }

    Row(
        Modifier
            .fillMaxWidth()
            .background(bgColor, RoundedCornerShape(6.dp))
            .padding(
                vertical   = 2.dp,
                horizontal = if (isCurrent || isMyStop) 4.dp else 0.dp
            ),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.width(20.dp)
        ) {
            Box(
                Modifier
                    .size(if (isCurrent) 16.dp else 11.dp)
                    .clip(CircleShape)
                    .background(dotColor)
                    .then(
                        if (isCurrent)
                            Modifier.border(1.5.dp, Color(0xFF1B5E20), CircleShape)
                        else Modifier
                    ),
                contentAlignment = Alignment.Center
            ) {
                if (isCurrent)
                    Box(Modifier.size(6.dp).clip(CircleShape).background(Color.White))
            }
            if (!isLast) {
                Box(
                    Modifier.width(2.dp).height(30.dp).background(
                        if (isPassed || isCurrent) Color(0xFF4CAF50) else Color(0xFFE0E0E0)
                    )
                )
            }
        }
        Spacer(Modifier.width(6.dp))
        Column(Modifier.weight(1f).padding(vertical = 3.dp)) {
            Text(
                stop.village.name,
                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                fontSize   = if (isCurrent) 12.sp else 11.sp,
                color      = if (isPassed) Color(0xFF9E9E9E) else Color(0xFF212121),
                maxLines   = 1,
                overflow   = TextOverflow.Ellipsis
            )
            val sub = when {
                isCurrent -> "BUS IS HERE"
                isPassed  -> "Passed"
                isMyStop  -> "Your Stop"
                stop.etaMinutes != null && stop.etaMinutes > 0 -> "~${stop.etaMinutes} mins"
                stop.village.avgMinutesToNext > 0 -> "${stop.village.avgMinutesToNext} min"
                else -> "Last stop"
            }
            Text(
                sub,
                fontSize = 8.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                color    = if (isCurrent) Color(0xFF2E7D32) else Color(0xFF9E9E9E)
            )
        }
        when {
            isCurrent ->
                Box(
                    Modifier
                        .background(Color(0xFF2E7D32), RoundedCornerShape(4.dp))
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    Text("On Time", fontSize = 8.sp,
                        color = Color.White, fontWeight = FontWeight.Bold)
                }
            stop.etaMinutes != null && stop.etaMinutes > 0 ->
                Column(horizontalAlignment = Alignment.End) {
                    Text("~${stop.etaMinutes}", fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF1565C0), maxLines = 1)
                    Text("MINS", fontSize = 7.sp, color = Color(0xFF9E9E9E))
                }
            isPassed ->
                Text(
                    timeFmt.format(Date(System.currentTimeMillis() - 15 * 60000)),
                    fontSize = 8.sp, color = Color(0xFF9E9E9E), maxLines = 1
                )
        }
    }
}