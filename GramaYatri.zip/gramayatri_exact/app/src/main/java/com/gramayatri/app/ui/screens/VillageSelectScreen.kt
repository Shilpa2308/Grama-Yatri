package com.gramayatri.app.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.location.Geocoder
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.gramayatri.app.model.Village
import com.gramayatri.app.viewmodel.BusViewModel
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VillageSelectScreen(
    vm: BusViewModel,
    onBack: () -> Unit,
    onVillageSelected: () -> Unit
) {
    val context = LocalContext.current
    val routes  by vm.routes.collectAsState()
    val rid     by vm.selectedRouteId.collectAsState()
    val route   = routes.firstOrNull { it.id == rid }

    var detectedVillage  by remember { mutableStateOf<String?>(null) }
    var suggestedVillage by remember { mutableStateOf<Village?>(null) }
    var locationStatus   by remember { mutableStateOf("Tap to detect your location") }
    var isDetecting      by remember { mutableStateOf(false) }

    // Normalize city name variants
    fun normalize(text: String): String {
        return text.lowercase()
            .replace("bengaluru", "bangalore")
            .replace("bengalooru", "bangalore")
            .replace("banglore", "bangalore")
            .replace("majestic, bangalore", "bangalore")
            .replace("majestic", "bangalore")
            .trim()
    }

    fun findNearestVillage(lat: Double, lng: Double) {
        isDetecting = true
        locationStatus = "Detecting your location..."
        try {
            val geocoder = Geocoder(context, Locale.getDefault())
            @Suppress("DEPRECATION")
            val addresses = geocoder.getFromLocation(lat, lng, 1)
            if (!addresses.isNullOrEmpty()) {
                val addr = addresses[0]
                val locality = addr.locality
                    ?: addr.subLocality
                    ?: addr.subAdminArea
                    ?: addr.adminArea
                    ?: "Unknown"
                detectedVillage = locality
                locationStatus  = "Detected: $locality"

                val localityNorm = normalize(locality)

                // Extended smart matching
                val matched = route?.villages?.find { v ->
                    val vNorm = normalize(v.name)

                    // Direct contains match
                    vNorm.contains(localityNorm) ||
                            localityNorm.contains(vNorm) ||
                            // Word-by-word match from village name
                            v.name.lowercase().split(" ", ",").filter { it.length > 3 }.any { word ->
                                localityNorm.contains(normalize(word))
                            } ||
                            // Word-by-word match from locality
                            locality.lowercase().split(" ", ",").filter { it.length > 3 }.any { word ->
                                vNorm.contains(normalize(word))
                            } ||
                            // Normalized both sides
                            normalize(v.name).contains(localityNorm) ||
                            localityNorm.contains(normalize(v.name))
                }
                suggestedVillage = matched

                if (matched == null) {
                    locationStatus = "Detected: $locality — select stop manually below"
                }
            } else {
                locationStatus = "Could not detect location. Try again."
            }
        } catch (e: Exception) {
            locationStatus = "Error: ${e.message}"
        }
        isDetecting = false
    }

    val locationLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        val granted = perms[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                perms[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (granted) {
            val fusedClient = com.google.android.gms.location.LocationServices
                .getFusedLocationProviderClient(context)
            try {
                fusedClient.lastLocation.addOnSuccessListener { loc ->
                    if (loc != null) findNearestVillage(loc.latitude, loc.longitude)
                    else locationStatus = "Could not get location. Try again."
                }
            } catch (e: SecurityException) {
                locationStatus = "Permission denied"
            }
        } else {
            locationStatus = "Location permission denied. Select manually."
        }
    }

    fun detectLocation() {
        val fine = ContextCompat.checkSelfPermission(
            context, Manifest.permission.ACCESS_FINE_LOCATION)
        if (fine == PackageManager.PERMISSION_GRANTED) {
            val fusedClient = com.google.android.gms.location.LocationServices
                .getFusedLocationProviderClient(context)
            try {
                fusedClient.lastLocation.addOnSuccessListener { loc ->
                    if (loc != null) findNearestVillage(loc.latitude, loc.longitude)
                    else locationStatus = "Could not get location. Move outside and try."
                }
            } catch (e: SecurityException) {
                locationStatus = "Permission error"
            }
        } else {
            locationLauncher.launch(arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ))
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            route?.name ?: "Select Village",
                            fontWeight = FontWeight.Bold, fontSize = 16.sp
                        )
                        Text(
                            "Where are you boarding?", fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back", tint = Color.White
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor    = Color(0xFF1B5E20),
                    titleContentColor = Color.White
                )
            )
        },
        containerColor = Color(0xFFF1F8E9)
    ) { pad ->
        Column(
            Modifier.padding(pad).padding(16.dp).fillMaxSize()
        ) {

            // ── GPS DETECT CARD ────────────────────────────────────────
            Card(
                modifier  = Modifier.fillMaxWidth(),
                colors    = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Column(Modifier.padding(14.dp)) {
                    Text(
                        "Detect My Location",
                        fontWeight = FontWeight.Bold,
                        fontSize   = 13.sp,
                        color      = Color(0xFF1B5E20)
                    )
                    Text(
                        "Auto-select the nearest village stop to you",
                        fontSize = 11.sp,
                        color    = Color(0xFF757575)
                    )
                    Spacer(Modifier.height(10.dp))

                    Button(
                        onClick  = { detectLocation() },
                        enabled  = !isDetecting,
                        modifier = Modifier.fillMaxWidth(),
                        colors   = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF1B5E20))
                    ) {
                        if (isDetecting) {
                            CircularProgressIndicator(
                                modifier    = Modifier.size(16.dp),
                                color       = Color.White,
                                strokeWidth = 2.dp
                            )
                            Spacer(Modifier.width(8.dp))
                            Text("Detecting...")
                        } else {
                            Icon(
                                Icons.Default.MyLocation,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(8.dp))
                            Text("Use My Current Location")
                        }
                    }

                    Spacer(Modifier.height(6.dp))

                    // Status text
                    Text(
                        locationStatus,
                        fontSize = 11.sp,
                        color    = when {
                            suggestedVillage != null  -> Color(0xFF2E7D32)
                            detectedVillage != null   -> Color(0xFFE65100)
                            else                      -> Color(0xFF757575)
                        }
                    )

                    // ── Suggested village card ───────────────────────
                    if (suggestedVillage != null) {
                        Spacer(Modifier.height(10.dp))
                        Card(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    vm.selectVillage(suggestedVillage!!.id)
                                    onVillageSelected()
                                },
                            colors    = CardDefaults.cardColors(
                                containerColor = Color(0xFFE8F5E9)),
                            elevation = CardDefaults.cardElevation(0.dp)
                        ) {
                            Row(
                                Modifier.padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Default.LocationOn,
                                    contentDescription = null,
                                    tint     = Color(0xFF2E7D32),
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(Modifier.width(10.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(
                                        "Nearest stop: ${suggestedVillage!!.name}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize   = 13.sp,
                                        color      = Color(0xFF1B5E20)
                                    )
                                    Text(
                                        "Tap to select this stop",
                                        fontSize = 11.sp,
                                        color    = Color(0xFF757575)
                                    )
                                }
                                Text(
                                    "SELECT",
                                    fontSize   = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color      = Color(0xFF2E7D32)
                                )
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(16.dp))

            Text(
                "Or select your stop manually:",
                fontWeight = FontWeight.SemiBold,
                fontSize   = 13.sp,
                color      = Color(0xFF1B5E20)
            )
            Spacer(Modifier.height(8.dp))

            // ── MANUAL VILLAGE LIST ────────────────────────────────────
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(route?.villages ?: emptyList(), key = { it.id }) { v ->
                    val isNearest = v.id == suggestedVillage?.id
                    Card(
                        modifier  = Modifier
                            .fillMaxWidth()
                            .clickable {
                                vm.selectVillage(v.id)
                                onVillageSelected()
                            },
                        colors    = CardDefaults.cardColors(
                            containerColor = if (isNearest)
                                Color(0xFFE8F5E9) else Color.White
                        ),
                        elevation = CardDefaults.cardElevation(
                            if (isNearest) 4.dp else 2.dp
                        )
                    ) {
                        Row(
                            Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.LocationOn,
                                contentDescription = null,
                                tint     = if (isNearest) Color(0xFF1B5E20)
                                else Color(0xFF2E7D32),
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    v.name,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize   = 14.sp
                                )
                                if (v.avgMinutesToNext > 0)
                                    Text(
                                        "~${v.avgMinutesToNext} min to next stop",
                                        fontSize = 11.sp,
                                        color    = Color(0xFF757575)
                                    )
                                else
                                    Text(
                                        "Last stop on this route",
                                        fontSize = 11.sp,
                                        color    = Color(0xFF757575)
                                    )
                            }
                            if (isNearest) {
                                Box(
                                    modifier = Modifier
                                        .then(Modifier),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        "NEAR YOU",
                                        fontSize   = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color      = Color(0xFF1B5E20)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}