package com.gramayatri.app.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.gramayatri.app.ui.components.RouteTimeline
import com.gramayatri.app.viewmodel.BusViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LiveTrackingScreen(vm: BusViewModel, onBack: () -> Unit) {
    val context        = LocalContext.current
    val routes         by vm.routes.collectAsState()
    val rid            by vm.selectedRouteId.collectAsState()
    val vid            by vm.selectedVillageId.collectAsState()
    val stops          by vm.stops.collectAsState()
    val pings          by vm.pings.collectAsState()
    val alerts         by vm.alerts.collectAsState()
    val pingSuccess    by vm.pingSuccess.collectAsState()
    val locationStatus by vm.locationStatus.collectAsState()

    val route     = routes.firstOrNull { it.id == rid }
    val myStop    = stops.firstOrNull { it.village.id == vid }
    val myVillage = route?.villages?.firstOrNull { it.id == vid }

    var alertText       by remember { mutableStateOf("") }
    var showAlertDialog by remember { mutableStateOf(false) }
    val timeFmt = remember { SimpleDateFormat("hh:mm a", Locale.getDefault()) }
    val snackbarHostState = remember { SnackbarHostState() }

    // Location permission
    val locationLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { perms ->
        val granted = perms[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
                      perms[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (granted) vm.fetchLocation()
    }

    LaunchedEffect(Unit) {
        val fine = ContextCompat.checkSelfPermission(
            context, Manifest.permission.ACCESS_FINE_LOCATION)
        if (fine == PackageManager.PERMISSION_GRANTED) vm.fetchLocation()
        else locationLauncher.launch(arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION))
    }

    LaunchedEffect(pingSuccess) {
        pingSuccess?.let { snackbarHostState.showSnackbar(it, duration = SnackbarDuration.Short) }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(route?.name ?: "Live Tracking",
                            fontWeight = FontWeight.Bold, fontSize = 17.sp)
                        Text("Live Community Bus Tracker", fontSize = 11.sp,
                            color = Color.White.copy(alpha = 0.85f))
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color(0xFF1B5E20),
                    titleContentColor = Color.White
                )
            )
        },
        containerColor = Color(0xFFF1F8E9)
    ) { pad ->
        Column(
            Modifier.padding(pad).padding(horizontal = 14.dp, vertical = 10.dp)
                .fillMaxSize().verticalScroll(rememberScrollState())
        ) {

            // ── ALERT BANNER (spec: "The morning bus is cancelled today") ──
            if (alerts.isNotEmpty()) {
                alerts.take(2).forEach { a ->
                    Row(
                        Modifier.fillMaxWidth().padding(bottom = 8.dp)
                            .background(Color(0xFFC62828), RoundedCornerShape(8.dp))
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.NotificationsActive,
                            contentDescription = null,
                            tint = Color.White, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text(a.message, color = Color.White,
                                fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("Reported by ${a.reporterName}",
                                color = Color.White.copy(alpha = 0.85f), fontSize = 11.sp)
                        }
                    }
                }
            }

            // ── MY STOP ETA CARD (spec: "Bus will reach your village in ~15 mins") ──
            myStop?.let { stop ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors   = CardDefaults.cardColors(containerColor = Color(0xFF2E7D32)),
                    elevation = CardDefaults.cardElevation(4.dp),
                    shape    = RoundedCornerShape(12.dp)
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Your Stop: ${myVillage?.name ?: "-"}",
                            color = Color.White.copy(alpha = 0.9f),
                            fontSize = 13.sp)
                        Spacer(Modifier.height(4.dp))
                        val etaText = when {
                            stop.isCurrent          -> "Bus is here at your stop now!"
                            stop.isPassed           -> "Bus has already passed your stop"
                            stop.etaMinutes == null -> "Waiting for first ping..."
                            stop.etaMinutes == 0    -> "Bus is arriving now!"
                            else -> "Bus will reach your village in ~${stop.etaMinutes} mins"
                        }
                        Text(etaText,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp)
                    }
                }
                Spacer(Modifier.height(12.dp))
            }

            // ── LOCATION ──
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors   = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(1.dp)
            ) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.LocationOn, contentDescription = null,
                        tint = Color(0xFF2E7D32), modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Your Location", fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold, color = Color(0xFF1B5E20))
                        Text(locationStatus, fontSize = 11.sp, color = Color(0xFF555555))
                    }
                    TextButton(onClick = { vm.fetchLocation() }) { Text("Refresh") }
                }
            }

            Spacer(Modifier.height(12.dp))

            // ── PING BUTTONS (spec: "I am on the bus" / "Bus just passed me") ──
            Text("Report Bus Position", fontWeight = FontWeight.Bold,
                fontSize = 14.sp, color = Color(0xFF1B5E20))
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(
                    onClick  = { vm.pingOnBus() },
                    modifier = Modifier.weight(1f),
                    colors   = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
                ) {
                    Text("I am on the bus", fontSize = 13.sp)
                }
                OutlinedButton(
                    onClick  = { vm.pingPassedStop() },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Bus just passed me", fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(
                onClick  = { showAlertDialog = true },
                modifier = Modifier.fillMaxWidth(),
                colors   = ButtonDefaults.outlinedButtonColors(
                    contentColor = Color(0xFFC62828))
            ) {
                Icon(Icons.Default.Warning, contentDescription = null,
                    modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(6.dp))
                Text("Report Alert  (cancelled / delayed)", fontSize = 13.sp)
            }

            Spacer(Modifier.height(20.dp))

            // ── ROUTE TIMELINE (spec: Vertical Stepper) ──
            Text("Route View", fontWeight = FontWeight.Bold,
                fontSize = 14.sp, color = Color(0xFF1B5E20))
            Text("All villages on this route with live ETA",
                fontSize = 11.sp, color = Color(0xFF757575))
            Spacer(Modifier.height(12.dp))

            Card(
                modifier  = Modifier.fillMaxWidth(),
                colors    = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Column(Modifier.padding(16.dp)) {
                    RouteTimeline(stops = stops, selectedVillageId = vid)
                }
            }

            Spacer(Modifier.height(20.dp))

            // ── RECENT PINGS (spec: shows reporter name "Reported by Ravi") ──
            if (pings.isNotEmpty()) {
                Text("Recent Reports", fontWeight = FontWeight.Bold,
                    fontSize = 14.sp, color = Color(0xFF1B5E20))
                Spacer(Modifier.height(8.dp))
                pings.take(6).forEach { p ->
                    Card(
                        Modifier.fillMaxWidth().padding(vertical = 3.dp),
                        colors    = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(1.dp)
                    ) {
                        Row(Modifier.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.size(36.dp).background(
                                    if (p.type == "ON_BUS") Color(0xFFE8F5E9)
                                    else Color(0xFFFFF3E0),
                                    RoundedCornerShape(8.dp)
                                ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    if (p.type == "ON_BUS") "ON" else "BY",
                                    fontSize = 10.sp, fontWeight = FontWeight.Bold,
                                    color = if (p.type == "ON_BUS") Color(0xFF2E7D32)
                                            else Color(0xFFE65100)
                                )
                            }
                            Spacer(Modifier.width(10.dp))
                            Column {
                                val action = if (p.type == "ON_BUS")
                                    "Bus at ${p.villageName}"
                                else
                                    "Bus passed ${p.villageName}"
                                Text(action, fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.sp)
                                // Spec: show reporter name
                                Text("Reported by ${p.reporterName}  •  ${timeFmt.format(Date(p.timestamp))}",
                                    fontSize = 11.sp, color = Color(0xFF757575))
                            }
                        }
                    }
                }
            } else {
                Card(
                    Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Box(Modifier.padding(20.dp).fillMaxWidth(),
                        contentAlignment = Alignment.Center) {
                        Text("No pings yet. Be the first to report!",
                            fontSize = 13.sp, color = Color(0xFF9E9E9E))
                    }
                }
            }

            Spacer(Modifier.height(16.dp))
        }
    }

    // Alert dialog
    if (showAlertDialog) {
        AlertDialog(
            onDismissRequest = { showAlertDialog = false },
            icon  = { Icon(Icons.Default.Warning, contentDescription = null,
                tint = Color(0xFFC62828)) },
            title = { Text("Report Community Alert") },
            text  = {
                Column {
                    Text("Quick options:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    listOf(
                        "The morning bus is cancelled today",
                        "Bus is running 30 minutes late",
                        "Bus is full, next one coming",
                        "Road block near the route"
                    ).forEach { s ->
                        OutlinedButton(
                            onClick  = { alertText = s },
                            modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                        ) { Text(s, fontSize = 12.sp) }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value         = alertText,
                        onValueChange = { alertText = it },
                        label         = { Text("Or type your own message") },
                        modifier      = Modifier.fillMaxWidth(),
                        minLines      = 2
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick  = { vm.postAlert(alertText); alertText = ""; showAlertDialog = false },
                    enabled  = alertText.isNotBlank(),
                    colors   = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
                ) { Text("Post Alert") }
            },
            dismissButton = {
                TextButton(onClick = { showAlertDialog = false }) { Text("Cancel") }
            }
        )
    }
}
