package com.gramayatri.app.ui.screens

import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gramayatri.app.viewmodel.BusViewModel

@Composable
fun WelcomeScreen(vm: BusViewModel, onContinue: () -> Unit) {

    var localName   by remember { mutableStateOf("") }
    var nameTouched by remember { mutableStateOf(false) }
    val nameIsValid = localName.isNotBlank()

    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(
                listOf(Color(0xFF1B5E20), Color(0xFF2E7D32), Color(0xFF388E3C))
            )
        )
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())   // ← scroll added
                .imePadding()                            // ← keyboard pushes content up
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Bus icon circle
            Box(
                Modifier.size(90.dp).clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.DirectionsBus,
                    contentDescription = null,
                    tint     = Color.White,
                    modifier = Modifier.size(52.dp)
                )
            }

            Spacer(Modifier.height(24.dp))

            Text(
                "Welcome to",
                color    = Color.White.copy(alpha = 0.85f),
                fontSize = 16.sp
            )
            Text(
                "GRAMA-YATRI",
                color      = Color.White,
                fontSize   = 32.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 2.sp
            )
            Text(
                "COMMUNITY TRANSIT LOG",
                color         = Color.White.copy(alpha = 0.7f),
                fontSize      = 11.sp,
                letterSpacing = 3.sp
            )

            Spacer(Modifier.height(12.dp))

            Text(
                "A community-powered bus tracker.\nPassengers ping the bus — everyone gets live ETA.",
                color       = Color.White.copy(alpha = 0.8f),
                fontSize    = 13.sp,
                textAlign   = TextAlign.Center,
                lineHeight  = 20.sp
            )

            Spacer(Modifier.height(36.dp))

            // ── Name input card ──────────────────────────────────────
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape    = RoundedCornerShape(16.dp),
                colors   = CardDefaults.cardColors(containerColor = Color.White)
            ) {
                Column(Modifier.padding(20.dp)) {
                    Text(
                        "Enter your name to continue",
                        fontWeight = FontWeight.SemiBold,
                        fontSize   = 14.sp,
                        color      = Color(0xFF1B5E20)
                    )
                    Text(
                        "Your name appears on every ping you send",
                        fontSize = 11.sp,
                        color    = Color(0xFF757575)
                    )
                    Spacer(Modifier.height(12.dp))

                    OutlinedTextField(
                        value         = localName,
                        onValueChange = {
                            localName   = it
                            nameTouched = true
                        },
                        label         = { Text("Your name *") },
                        placeholder   = { Text("e.g. Ravi, Kavya, Shilpa, Priya...") },
                        singleLine    = true,
                        isError       = nameTouched && !nameIsValid,
                        supportingText = {
                            if (nameTouched && !nameIsValid)
                                Text(
                                    "Please enter your name to continue",
                                    color = MaterialTheme.colorScheme.error
                                )
                            else
                                Text("This name will show on all your pings")
                        },
                        leadingIcon = {
                            Icon(Icons.Default.Person, null,
                                tint = Color(0xFF2E7D32))
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFF2E7D32),
                            focusedLabelColor  = Color(0xFF2E7D32)
                        )
                    )

                    Spacer(Modifier.height(16.dp))

                    Button(
                        onClick = {
                            nameTouched = true
                            if (nameIsValid) {
                                vm.setReporterName(localName.trim())
                                onContinue()
                            }
                        },
                        modifier = Modifier.fillMaxWidth().height(50.dp),
                        shape    = RoundedCornerShape(12.dp),
                        colors   = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF1B5E20)
                        )
                    ) {
                        Text(
                            "Get Started",
                            fontSize   = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            Spacer(Modifier.height(24.dp))

            Text(
                "Low data mode enabled  •  Community powered",
                color    = Color.White.copy(alpha = 0.55f),
                fontSize = 11.sp
            )

            Spacer(Modifier.height(16.dp))
        }
    }
}